//
//  claimcelldetail.swift
//  finder2work
//
//  Created by Harrison Fei on 1/16/18.
//  Copyright © 2018 Harrison Fei. All rights reserved.
//

import UIKit


class claimcelldetail: UIViewController {
    

    @IBOutlet weak var dateTxt1: UILabel!
    @IBOutlet weak var loctxt1: UILabel!
    @IBOutlet weak var itemtxt1: UILabel!
    @IBOutlet weak var desctext1: UILabel!
    @IBOutlet weak var subtxt1: UILabel!
    @IBOutlet weak var claimby1: UILabel!
    @IBOutlet weak var dateclaim: UILabel!
        var id = ""
    
    var rowdata:claimedItem?
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? deleteclaim{
            destination.deleteId = (rowdata?.id)!
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        dateTxt1.text = rowdata?.foundDateTime
        loctxt1.text = rowdata?.location
        itemtxt1.text = rowdata?.name
        desctext1.text = rowdata?.description
        subtxt1.text = rowdata?.submitby
        claimby1.text = rowdata?.claimby
        dateclaim.text = rowdata?.claimon
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
