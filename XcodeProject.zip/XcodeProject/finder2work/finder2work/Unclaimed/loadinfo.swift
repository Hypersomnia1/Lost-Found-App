//
//  loadinfo.swift
//  finder2work
//
//  Created by Harrison Fei on 1/15/18.
//  Copyright © 2018 Harrison Fei. All rights reserved.
//

import UIKit

class loadinfo: UIViewController {
    
    @IBOutlet weak var datetxt: UILabel!
    @IBOutlet weak var locationtxt: UILabel!
    @IBOutlet weak var itemtxt: UILabel!
    @IBOutlet weak var descriptxt: UILabel!
    @IBOutlet weak var submituser: UILabel!
    @IBOutlet weak var claimby: UITextField!
    var id = ""
    @IBAction func claimitem(_ sender: Any) {
        
        if (claimby.text != "")
        {
        //put the link of the php file here. The php file connects the mysql and swift
        let request = NSMutableURLRequest(url: NSURL(string: "http://c-76-97-180-216.hsd1.ga.comcast.net:8080/CrunchifyTutorials/updateItem.jsp?")! as URL)
        request.httpMethod = "POST"
        
        let postString = "claimedby=\(claimby.text!)&id=\(id)"
        print (postString)
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("responseString = \(responseString)")
        }
        task.resume()
        
        
        let alertController = UIAlertController(title: "Updated", message:
            "Successfully Claimed", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: { action in self.performSegue(withIdentifier: "backfromclaim", sender: self) }))

        self.present(alertController, animated: true, completion: nil)
        
        claimby.text = ""
        }
        else{
            
            let alertController = UIAlertController(title: "Error", message:
                "Please enter Claim name", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        
        
    }
    
    var rowdata:Item?
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? deleteItem{
            destination.deleteId = (rowdata?.id)!
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        datetxt.text = rowdata?.foundDateTime
        locationtxt.text = rowdata?.location
        itemtxt.text = rowdata?.name
        descriptxt.text = rowdata?.description
        submituser.text = rowdata?.submitby
        id = (rowdata?.id)!
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

