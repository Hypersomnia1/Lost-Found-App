//
//  deleteItem.swift
//  finder2work
//
//  Created by Harrison Fei on 1/15/18.
//  Copyright © 2018 Harrison Fei. All rights reserved.
//

import UIKit

class deleteItem: UIViewController {
    
    var deleteId: String = ""
    
    @IBOutlet weak var staffCode: UITextField!
    
    @IBAction func del1(_ sender: Any) {
        if (staffCode.text == "123456")
        {
        let request = NSMutableURLRequest(url: NSURL(string: "http://c-76-97-180-216.hsd1.ga.comcast.net:8080/CrunchifyTutorials/deleteItem.jsp?")! as URL)
        request.httpMethod = "POST"
        
        let postString = "id=\(deleteId)"
        print (postString)
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("responseString = \(responseString)")
        }
        task.resume()
        
        let alertController = UIAlertController(title: "Deleted", message:
            "Successfully Deleted", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: { action in self.performSegue(withIdentifier: "backfromdel", sender: self) }))
        
        self.present(alertController, animated: true, completion: nil)
        }
        else{
            
            let alertController = UIAlertController(title: "Error", message:
                "Please Enter Valid Staff Code", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
